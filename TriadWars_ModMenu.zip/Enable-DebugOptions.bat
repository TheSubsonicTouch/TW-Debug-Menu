@echo off
cd /d "%~dp0"
if exist "LocalServer\useroptions.py" (
    python "LocalServer\useroptions.py" set DebugUIMenuOptions true
    echo DebugUIMenuOptions enabled.
) else (
    echo LocalServer\useroptions.py not found in this folder.
)
pause
