# Triad Wars Mod Menu — Fresh Game Folder Install Guide

Everything in this folder is structured so you can **copy and paste (or extract) it straight into a fresh Triad Wars game folder** (the folder containing `TriadWars.exe`, `Play-TriadWars.bat`, and `LocalServer\`).

---

## Quick Install (Fresh Triad Wars Folder)

Copy all files from this folder directly into your Triad Wars root folder:

```text
<Your Triad Wars Folder>\
├── TriadWars.exe               (existing game executable)
├── Play-TriadWars.bat          (existing offline launcher)
├── dinput8.dll                 <-- Mod Menu DLL (loads automatically on game start)
├── Shaders\                    <-- ReShade .ini presets selectable in the Mod Menu
│   ├── Cinematic_Triad.ini
│   ├── Neon_Night_Rain.ini
│   ├── Realistic_HongKong.ini
│   └── Vanilla_Clean.ini
├── LocalServer\
│   └── state.py                <-- Initializes TriadLevel: 1 on brand-new saves
└── Enable-DebugOptions.bat     <-- (Optional) Enables DebugUIMenuOptions in useroptions
```

1. Copy **`dinput8.dll`**, **`Shaders\`**, and **`LocalServer\state.py`** into your fresh Triad Wars folder (allow overwriting `LocalServer\state.py` when prompted).
2. *(Optional)* Run **`Enable-DebugOptions.bat`** once if you also want `DebugUIMenuOptions` enabled in `LocalServer\useroptions.py`.
3. Launch the game normally via **`Play-TriadWars.bat`** (or start `LocalServer` + `TriadWars.exe`).
4. Once in-game, press **`Insert`** on your keyboard or **`Start`** on an Xbox/XInput controller to open the **Triad Wars Mod Menu**.

---

## Controls

| Action | Keyboard | Controller (XInput) | Mouse |
| :--- | :--- | :--- | :--- |
| **Open / Close Menu** | `Insert` | `Start` | — |
| **Move Up / Down** | `Up` / `Down` Arrows | `D-Pad Up` / `D-Pad Down` | Point & Scroll |
| **Change Option / Slider** | `Left` / `Right` Arrows | `D-Pad Left` / `D-Pad Right` | Click `<` `>` / Drag |
| **Activate / Apply** | `Enter` | `A` Button | Left-Click |
| **Close Menu** | `Backspace` | `B` Button | Click `X` |

---

## Included Features

- **Chinese Dragon Theme Overlay** — Styled DirectX 11 Dear ImGui overlay (crimson, dark lacquer, and gold accents with corner dragon-frame ornaments).
- **Weather Switcher** — Live in-memory Hong Kong weather presets (`Sunny`, `Cloudy`, `Light rain`, `Heavy rain`) via `UFG::TimeOfDayManager` + wet-surface override.
- **Level & Progression Editor** — Set **Enforcer** (`1–50` via exact XP table), **Rackets** (scales turf rackets across `TurfBag`), **Triad** (`TriadLevel`), or **Rivals** (`opponents[]` EnforcerXP, TriadLevel & rackets) and hot-reload `LocalServer`.
- **Unlock All Content** — One-click full progression & bonus content unlocker:
  - Unlocks all Enforcer Upgrades (`EnforcerUpgradesBag`), Vehicles & Weapons (`InventoryBag`), Clothing (`CustomizationBag`), and Favours/Jobs/Activities (`FavoursBag`, resetting cooldown timers and granting missing favours).
  - Maxes Enforcer Level (`50`), Triad Level (`50`), and Racket tiers (`10`).
  - Works with full `LocalServer\devdata\gamedb.json` **and** falls back automatically to `LocalServer\data\*` on standard fresh offline installs.
  - Note: Launch the game at least once first so `LocalServer\state.json` exists, then click **Unlock All Content** and re-enter/reload safehouse or restart to pull the updated profile.
- **Shader Preset Selector (`Shaders\*.ini`)** — Lists any `.ini` preset inside `<GameFolder>\Shaders\` and copies the chosen preset to `<GameFolder>\ReShadePreset.ini`.
  - *Using with ReShade:* When installing ReShade on `TriadWars.exe`, select **DirectX 10/11/12** (which installs ReShade as `dxgi.dll` so it will not conflict with `dinput8.dll`) and set ReShade's active preset path to `ReShadePreset.ini`.
- **Built-in Engine Crash Guard** — Vectored Exception Handler (`spawn_guard`) that catches null-streamed resource dereferences and logs diagnostic output to `TW_MenuLog.txt` next to `TriadWars.exe`.
